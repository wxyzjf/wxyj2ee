<?php
$db_host="localhost";
$db_user="root";
$db_pwd="123456";
$database="ad2012";

$staffId = "G".$_POST["staffId"];
$sure = $_POST["sure"];

$dom = new DOMDocument("1.0", "utf-8");
header("Comtent-Type:text/plain; charset=utf-8");

$root = $dom->createElement("topping");
$dom->appendChild($root);

if (!mysql_connect($db_host, $db_user, $db_pwd)) {
	$status = 0;
    $status_f = $dom->createElement("status");
    $root->appendChild($status_f);
    $text = $dom->createTextNode($status);
    $status_f->appendChild($text);
    
    $errmsg = "Can't connect to database";
    $errmsg_f = $dom->createElement("errmsg");
    $root->appendChild($errmsg_f);
    $text = $dom->createTextNode($errmsg);
    $errmsg_f->appendChild($text);
    
    die("Can't connect to database");
}
     
if (!mysql_select_db($database)) {
	$status = 0;
    $status_f = $dom->createElement("status");
    $root->appendChild($status_f);
    $text = $dom->createTextNode($status);
    $status_f->appendChild($text);
    
    $errmsg = "Can't select database";
    $errmsg_f = $dom->createElement("errmsg");
    $root->appendChild($errmsg_f);
    $text = $dom->createTextNode($errmsg);
    $errmsg_f->appendChild($text);
    
    die("Can't select database");
}
      
mysql_query("set names 'utf8'");

$sql = "select staff_id,staff_name_eng,staff_name_chi,department,seat_no,checkin_flag,checkin_date,shift_code from check_in_info where staff_id = '" . $staffId ."'";

$result =  mysql_query($sql);
if (!$result) {
	$status = 0;
    $status_f = $dom->createElement("status");
    $root->appendChild($status_f);
    $text = $dom->createTextNode($status);
    $status_f->appendChild($text);
    
    $errmsg = "Query to show fields from table failed";
    $errmsg_f = $dom->createElement("errmsg");
    $root->appendChild($errmsg_f);
    $text = $dom->createTextNode($errmsg);
    $errmsg_f->appendChild($text);
    
    die("Query to show fields from table failed");
}
	
$num_rows = mysql_num_rows($result);
      
if ($num_rows == 0) {
    $status = 0;
    $status_f = $dom->createElement("status");
    $root->appendChild($status_f);
    $text = $dom->createTextNode($status);
    $status_f->appendChild($text);
    
    $errmsg = "No data found!";
    $errmsg_f = $dom->createElement("errmsg");
    $root->appendChild($errmsg_f);
    $text = $dom->createTextNode($errmsg);
    $errmsg_f->appendChild($text);
} else if ($num_rows == 1) {
    $row = mysql_fetch_row($result);
    $staffId = $row[0];
    $staffNameEng = $row[1];
    $staffNameChi = $row[2];
    $department = $row[3];
    $seatNo = $row[4];
    $checkinFlag = $row[5];
    $checkinDate = $row[6];
    $shiftCode = $row[7];
    if (($checkinFlag == "N" && ($shiftCode == "@" || $shiftCode == "AL") && $sure == "N")||($checkinFlag == "N" && $sure == "Y")) {
        $sql = "update check_in_info set checkin_date=now(),checkin_flag='Y' where staff_id='".$staffId."' and checkin_flag='N'";

        $result = mysql_query($sql);
                
        if (!$result) {
        	$status = 0;
            $status_f = $dom->createElement("status");
            $root->appendChild($status_f);
            $text = $dom->createTextNode($status);
            $status_f->appendChild($text);
            
            $errmsg = "Update table fields failed";
            $errmsg_f = $dom->createElement("errmsg");
            $root->appendChild($errmsg_f);
            $text = $dom->createTextNode($errmsg);
            $errmsg_f->appendChild($text);
            
            die("Update table fields failed");
        }
              
        $sql = "select staff_id,staff_name_eng,staff_name_chi,department,seat_no,checkin_flag,checkin_date from check_in_info where staff_id = '" . $staffId ."'";

        $result =  mysql_query($sql);

        if (!$result) {
        	$status = 0;
            $status_f = $dom->createElement("status");
            $root->appendChild($status_f);
            $text = $dom->createTextNode($status);
            $status_f->appendChild($text);
            
            $errmsg = "Query to show fields from table failed";
            $errmsg_f = $dom->createElement("errmsg");
            $root->appendChild($errmsg_f);
            $text = $dom->createTextNode($errmsg);
            $errmsg_f->appendChild($text);
            
            die("Query to show fields from table failed");
	    }
	
        $row = mysql_fetch_row($result);
        $staffId = $row[0];
        $staffNameEng = $row[1];
        $staffNameChi = $row[2];
        $department = $row[3];
        $seatNo = $row[4];
        $checkinFlag = $row[5];
        $checkinDate = $row[6];
        
        $status = 1;
        $status_f = $dom->createElement("status");
        $root->appendChild($status_f);
        $text = $dom->createTextNode($status);
        $status_f->appendChild($text);
    } else if ($shiftCode != "@" && $shiftCode != "AL" && $sure == "N" && $checkinFlag == "N") {
        $status = 1;
        $status_f = $dom->createElement("status");
        $root->appendChild($status_f);
        $text = $dom->createTextNode($status);
        $status_f->appendChild($text);
    } else if ($checkinFlag == "Y"){
        $status = 2;
        $status_f = $dom->createElement("status");
        $root->appendChild($status_f);
        $text = $dom->createTextNode($status);
        $status_f->appendChild($text);
    }

    $staffId_f = $dom->createElement("staffId");
    $root->appendChild($staffId_f);
    $text = $dom->createTextNode($staffId);
    $staffId_f->appendChild($text);

    $staffNameEng_f = $dom->createElement("staffNameEng");
    $root->appendChild($staffNameEng_f);
    $text = $dom->createTextNode($staffNameEng);
    $staffNameEng_f->appendChild($text);

    $staffNameChi_f = $dom->createElement("staffNameChi");
    $root->appendChild($staffNameChi_f);
    $text = $dom->createTextNode($staffNameChi);
    $staffNameChi_f->appendChild($text);

    $department_f = $dom->createElement("department");
    $root->appendChild($department_f);
    $text = $dom->createTextNode($department);
    $department_f->appendChild($text);

    $seatNo_f = $dom->createElement("seatNo");
    $root->appendChild($seatNo_f);
    $text = $dom->createTextNode($seatNo);
    $seatNo_f->appendChild($text);

    $checkinFlag_f = $dom->createElement("checkinFlag");
    $root->appendChild($checkinFlag_f);
    $text = $dom->createTextNode($checkinFlag);
    $checkinFlag_f->appendChild($text);

    $checkinDate_f = $dom->createElement("checkinDate");
    $root->appendChild($checkinDate_f);
    $text = $dom->createTextNode($checkinDate);
    $checkinDate_f->appendChild($text);
    
    $shiftCode_f = $dom->createElement("shiftCode");
    $root->appendChild($shiftCode_f);
    $text = $dom->createTextNode($shiftCode);
    $shiftCode_f->appendChild($text);

    mysql_free_result($result);
}

echo $dom->saveXML();
?>
