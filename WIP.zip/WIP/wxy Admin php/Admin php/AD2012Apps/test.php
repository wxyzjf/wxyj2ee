<html>
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title>Index</title>
  </head>
  <body>
    <form id="form1" name="form1" action="index.php" method="post">
      <table width="100%" cellpadding="0" cellspacing="10">
        <tr>
          <td>
            <input type="submit" class="button" style="cursor:hand" value="Click"></input>
          </td>
        </tr>
      </table>
      <input type="hidden" id="staffId" name="staffId" value="11135">
      <input type="hidden" id="sure" name="sure" value="N">
    </form>
  </body>
</html>
