<html>
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <link rel="stylesheet" href="checkin.css" type="text/css">
    <title>Upload Staff List</title>
  </head>
  <body>
    <form id="form1" name="form1" action="loadfile.php" method="post">
      <table width="100%" cellpadding="0" cellspacing="10">
        <tr>
          <td class="label">Please set the Staff List(.csv) in D:/wamp/www/Admin.</td>
        </tr>
        <tr>
          <td><input type="submit" class="button" style="cursor:hand" value="Upload"></input></td>
        </tr>
      </table>
    </form>
  </body>
</html>
