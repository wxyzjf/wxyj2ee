<?php 
$db_host="localhost";
$db_user="root";
$db_pwd="123456";
$database="ad2012";

$report_type = $_POST["report_type"];
if ($report_type != "") {
    $file_type = "vnd.ms-excel";
    $file_ending = ".xls";
    $sql = "";
    $file_name = "";
    if ($report_type == "1") {
        $sql = "select staff_id,staff_name_eng,staff_name_chi,department,seat_no,checkin_flag,checkin_date from check_in_info order by department, staff_id";
        $file_name = "All_Staff_List";
    } else if ($report_type == "2") {
        $sql = "select staff_id,staff_name_eng,staff_name_chi,department,seat_no,checkin_flag,checkin_date from check_in_info where checkin_flag = 'Y' order by department, staff_id"; 
        $file_name = "Checkin_Staff_List";
    } else if ($report_type == "3") {
        $sql = "select staff_id,staff_name_eng,staff_name_chi,department,seat_no,checkin_flag,checkin_date from check_in_info where checkin_flag = 'N' order by department, staff_id";
        $file_name = "Uncheckin_Staff_list";
    }
    
    header("Content-Type: application/$file_type; charset=utf-8");
    header("content-Disposition: attachment; filename = ".$file_name.$file_ending);
    header("Pragma:no-cache");
    header("Expires:0");

	if (!mysql_connect($db_host, $db_user, $db_pwd)) {
		die("Can't connect to database");
	}
     
	if (!mysql_select_db($database)) {
		die("Can't select database");
	}
      
    mysql_query("set names 'utf8'");

	$result =  mysql_query($sql);
	if (!$result) {
		die("Query to show fields from table failed");
	}
       
    echo "Staff ID"."\t"."Staff English Name"."\t"."Staff Chinese Name"."\t"."Department"."\t"."Seat No."."\t"."Check-in Flag"."\t"."Check-in Date";
      
    $count=0;
    while ($row = mysql_fetch_row($result)) {
        print("\n");
        echo $row[0]."\t".$row[1]."\t".iconv("utf-8","gbk",$row[2])."\t".$row[3]."\t=\"".$row[4]."\"\t".$row[5]."\t".$row[6]."\t";
        $count++;
    }
    print("\n\n");
    echo "Total:"."\t".$count;
      
    mysql_free_result($result);
    return(true);
}
?>