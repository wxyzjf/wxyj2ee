<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<script src="checkin.js" language="javascript"></script>
<link rel="stylesheet" href="checkin.css" type="text/css">
<title>Guangzhou Annual Dinner 2012 Admin</title>		
</head>
<body onload="">
<span class="caption">GZ Annual Dinner 2012 Check-in Admin</span><br>
<hr>
<br/>
<form id="adminForm" method="post" action="" target="below" >
<div id="ly1" style="position:absolute; left:0px; top:15%; width:15%; heigth:85%; z-index:2; overflow:none; ">
<table width="100%" cellpadding="0" cellspacing="10">
  <tr>
    <td><input type="button" class="button" onclick="changeFrame(1)" style="cursor:hand; width:98%" value="All Staff"></input></td>
  </tr>
  <tr>
    <td><input type="button" class="button" onclick="changeFrame(2)" style="cursor:hand; width:98%" value="Check-in Staff"></input></td>
  </tr>
  <tr>
    <td><input type="button" class="button" onclick="changeFrame(3)" style="cursor:hand; width:98%" value="Uncheck-in Staff"></input></td>
  </tr>
  <tr>
    <td><input type="button" class="button" onclick="changeFrame(4)" style="cursor:hand; width:98%" value="Cancel Check-in"></input></td>
  </tr>
  <tr>
    <td><input type="button" class="button" onclick="doClear();" style="cursor:hand; width:98%" value="Clear"></input></td>
  </tr>
</table>
<input type="hidden" id="action" name="action" value=""></input>
</form>
</div>
<div id="ly2" style="position:absolute; left:16%; top:15%; width:84%; height:85%; z-index:0; overflow:auto; ">
<iFrame width="95%" height="95%" src="" name="adminChildren" frameorder="5"></iFrame>
</div>
</body>
</html>