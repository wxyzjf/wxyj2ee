function fireFoxHandler(evt) {
  if (evt.keyCode == 13) {
    doValidate();
  }
}
function doSubmit() {
  if (event.keyCode == 13) {
    doValidate();
  }
}
function doCheck() {
  if (event.keyCode == 13) {
    return false;
  }
}
function doInit() {
  if (document.addEventListener) {
    document.addEventListener("keypress",fireFoxHandler,false);
  }
  setTimeout(function(){document.getElementById("staffId").focus();},2);
  //alert("focus!");
}
function doClear() {
  window.parent.location.href="index.php";
}
function doReset() {
  document.getElementById("staffId").value = "";
  document.getElementById("staffId").focus();
  document.getElementById("form4").action = "blank.php";
  document.getElementById("form4").submit();
}
function doCheckin() {
  document.getElementById("form2").submit();
}
function doAlert(msg,obj) {
  if (obj != null) {
    obj.focus();
  }
  document.getElementById("form4").action = "alert_message.php";
  document.getElementById("message").value = msg;
  document.getElementById("form4").submit();
}
function doValidate() {
  if (document.getElementById("staffId").value == "") {
    doAlert("Please input Staff ID!",document.getElementById("staffId"));
    return;
  }
  if (document.getElementById("staffId").value.length != 5) {
    doAlert("Invalid Staff ID!",document.getElementById("staffId"));
    return;
  }
  
  document.getElementById("form1").submit();
}
function chkNumOnly() {
  if (event.keyCode < 48 || event.keyCode > 57) {
    return false;
  } else {
    return true;
  }
}
function isNumber(str) {
  if (/^[0-9]+$/.test(str)) {
    return true;
  }
  return false;
}
function checkEmail(emailaddr) {
  if (emailaddr.trim().length >= 4) {
    return true;
  }
  return false;
}
String.prototype.trim=function() {
  return this.replace(/(^\s*)|(\s*$)/g,'');
}