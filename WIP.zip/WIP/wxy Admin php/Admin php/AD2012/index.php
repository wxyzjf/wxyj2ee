<html>
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title>Index</title>
  </head>
  <frameset border="0" frameborder="0" framespacing="0" rows="280,*">	
    <frame name="top" src="checkin_search.php" noresize scrolling="no" marginheight="0" marginwidth="0" frameborder="no">
    <frame name="below" src="blank.php" noresize scrolling="auto" marginheight="0" marginwidth="0" frameborder="no">
  </frameset>
</html>