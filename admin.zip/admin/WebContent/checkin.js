function doCheck() {
  if (event.keyCode == 13) {
    return false;
  }
}
function chkNumOnly() {
  if (event.keyCode < 48 || event.keyCode > 57) {
    return false;
  } else {
    return true;
  }
}
function isNumber(str) {
  if (/^[0-9]+$/.test(str)) {
    return true;
  }
  return false;
}
function genReport() {
  document.getElementById("reportForm").submit();
}
function changeFrame(open_flag) {
  document.getElementById("action"),value = open_flag;
  if (open_flag == 4) {
    window.adminChildren.location.href="cancelCheckin_index.jsp";
  } else if (open_flag == 1){
	  window.adminChildren.location.href="/admin/FindServlet?sql=1"; 
  } else if (open_flag == 2){
	  window.adminChildren.location.href="/admin/FindServlet?sql=2";
  } else if (open_flag == 3){
	  window.adminChildren.location.href="/admin/FindServlet?sql=3";
  }else{
	  window.adminChildren.location.href="showReport.jsp?action="+open_flag;
  }
}
function doCheckin() {
  document.getElementById("form2").submit();
}

function doCancelCheckin() {
	  document.getElementById("form2").submit();
	}
function doSubmit() {
  if (event.keyCode == 13) {
    doSearch();
  }
}
function doSearch() {
  if (document.getElementById("staffId").value == "") {
    doAlert("Please input Staff ID!",document.getElementById("staffId"));
    return;
  }
  if (document.getElementById("staffId").value.length != 5) {
    doAlert("Invalid Staff ID!",document.getElementById("staffId"));
    return;
  }
  document.getElementById("form1").action = "/admin/SearchServlet";
  document.getElementById("form1").submit();
}


function doCheckIn_c() {
	  if (document.getElementById("staffId").value == "") {
	    doAlert("Please input Staff ID!",document.getElementById("staffId"));
	    return;
	  }
	  if (document.getElementById("staffId").value.length != 5) {
	    doAlert("Invalid Staff ID!",document.getElementById("staffId"));
	    return;
	  }
	  document.getElementById("form1").action = "/admin/SelectServlet?flag=c";
	  document.getElementById("form1").submit();
	} 

function doAlert(msg,obj) {
  if (obj != null) {
    obj.focus();
  }
  document.getElementById("form4").action = "alert_message.jsp";
  document.getElementById("message").value = msg;
  document.getElementById("form4").submit();
}
function doReset() {
  document.getElementById("staffId").value = "";
  document.getElementById("staffId").focus();
  document.getElementById("form4").action = "cancelCheckin_blank.jsp";
  document.getElementById("form4").submit();
}
function doInit() {
  if (document.addEventListener) {
    document.addEventListener("keypress",fireFoxHandler,false);
  }
  setTimeout(function(){document.getElementById("staffId").focus();},2);
  //alert("focus!");
}
function doClear() {
  window.location.href = "admin.jsp";
}

function doCancel() {
	  window.location.href = "cancelCheckin_blank.jsp";
}




