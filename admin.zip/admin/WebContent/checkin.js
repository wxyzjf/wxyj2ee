function doCheck() {
  if (event.keyCode == 13) {
    return false;
  }
}
function chkNumOnly() {
  if (event.keyCode < 48 || event.keyCode > 57) {
    return false;
  } else {
    return true;
  }
}
function isNumber(str) {
  if (/^[0-9]+$/.test(str)) {
    return true;
  }
  return false;
}
function genReport() {
  document.getElementById("reportForm").submit();
}
function changeFrame(open_flag) {
  document.getElementById("action"),value = open_flag;
  if (open_flag == 4) {
    window.adminChildren.location.href="cancelCheckin_index.jsp";
  } else {
    //window.adminChildren.location.href="showReport.jsp?action="+open_flag;
	  window.adminChildren.location.href="showReport.jsp?action="+open_flag;
  }
}
function doCancelCheckin() {
  document.getElementById("form2").submit();
}
function doSubmit() {
  if (event.keyCode == 13) {
    doSearch();
  }
}
function doSearch() {
  if (document.getElementById("staffId").value == "") {
    doAlert("Please input Staff ID!",document.getElementById("staffId"));
    return;
  }
  if (document.getElementById("staffId").value.length != 5) {
    doAlert("Invalid Staff ID!",document.getElementById("staffId"));
    return;
  }
  
  document.getElementById("form1").submit();
}
function doAlert(msg,obj) {
  if (obj != null) {
    obj.focus();
  }
  document.getElementById("form4").action = "alert_message.jsp";
  document.getElementById("message").value = msg;
  document.getElementById("form4").submit();
}
function doReset() {
  document.getElementById("staffId").value = "";
  document.getElementById("staffId").focus();
  document.getElementById("form4").action = "cancelCheckin_blank.jsp";
  document.getElementById("form4").submit();
}
function doInit() {
  if (document.addEventListener) {
    document.addEventListener("keypress",fireFoxHandler,false);
  }
  setTimeout(function(){document.getElementById("staffId").focus();},2);
  //alert("focus!");
}
function doClear() {
  window.location.href = "admin.jsp";
}