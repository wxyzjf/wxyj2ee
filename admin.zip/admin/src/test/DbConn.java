package test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.PreparedStatement;
public class DbConn {
	private static String driver = "oracle.jdbc.driver.OracleDriver";
	private static String url = "jdbc:oracle:thin:@172.23.42.86:1521:gzsmcdev";
	private static String user = "gzsmcdev01";
	private static String password = "GZSMCDEV01";
	private static Connection conn = null;
	static {
		try {
			Class.forName(driver);
			System.out.println("-----load success-----");
			conn = (Connection) DriverManager.getConnection(url, user, password);
			System.out.println("-----conn success-----");
		} catch (ClassNotFoundException e) {
			System.out.println("Exception thrown : ClassNotFoundException ");
			e.printStackTrace();
		} catch (SQLException e) {
			System.out.println("Exception thrown : SQLException ");
			e.printStackTrace();
		}
	}

	public static Connection getConn() {
		return conn;
	}

	public static void close(Connection conn, PreparedStatement pstmt, ResultSet rs) {
		if (conn != null) {
			try {
				conn.close();
			} catch (Exception e) {
				System.out.println("Exception thrown : Connection cannot be closed ");
				e.printStackTrace();
			}
		}
		if (pstmt != null) {
			try {
				pstmt.close();
			} catch (Exception e) {
				System.out.println("Exception thrown : PreparedStatement cannot be closed ");
				e.printStackTrace();
			}
		}
		if (rs != null) {
			try {
				rs.close();
			} catch (Exception e) {
				System.out.println("Exception thrown : ResultSet cannot be closed ");
				e.printStackTrace();
			}
		}
	}
}
