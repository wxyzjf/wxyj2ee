package test;

import org.junit.jupiter.api.Test;

import com.dao.StaffDao;
import com.dao.impl.StaffDaoImpl;
import com.entity.Staff;

public class StaffTest {
	StaffDao staffDao = new StaffDaoImpl();
	@Test
	public void testUpdateStaff() {
		Staff staff = new Staff();
		staff.setStaff_no("");
		System.out.println(staffDao.update(staff));
	}
	@Test
	public void testSelectStaff() {
		Staff staff = new Staff();
		staff.setStaff_no("");
		System.out.println(staffDao.selectById(""));
	}
}
