package test;

import java.sql.Connection;
import java.util.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;

import org.apache.naming.java.javaURLContextFactory;

public class TestConn {
	private static PreparedStatement pstmt;
	//private static ResultSet rs;
	private static Connection conn;

	public static void select() {

		try {
			conn = DbConn.getConn();
			
			//Update table set datecolumn=to_date(?, ‘YYYYMMDDHH24MISS’) where staff_no=?
			
			//pstmt = conn.prepareStatement("select staff_no,testtime from eloise_test_time");
			//rs = pstmt.executeQuery();
			
			/*
			 * while (rs.next()) {
			 * 
			 * String staff_no = rs.getString("staff_no"); Timestamp timestamp =
			 * rs.getTimestamp("testtime"); System.out.println("staff_no = " + staff_no +
			 * "\t" + "timestamp = " + timestamp);
			 * System.out.println(timestamp.toString().substring(0,
			 * timestamp.toString().length()-2)); }
			 */
			System.out.println("1");
			//UPDATE ELOISE_TEST_DATE SET DATETEST = to_date('2019-07-05 16:22:22', 'YYYY-MM-DD HH24:MI:SS') WHERE staff_no='a';
			pstmt = conn.prepareStatement("UPDATE ELOISE_TEST_DATE SET DATETEST=? WHERE staff_no=?");
			System.out.println("2");
			//System.out.println(new java.sql.Date(System.currentTimeMillis()));
			//pstmt.setDate(1, new java.sql.Date(new SimpleDateFormat("YYYY-MM-dd HH:MM:SS").format(System.currentTimeMillis())));
			//pstmt.setDate(1, new java.sql.Date());
			//pstmt.setS(1, new java.sql.Date(new java.util.Date().getTime()) );
			System.out.println("3");
			pstmt.setString(2, "a");
		    System.out.println("4");
			System.out.println(pstmt.executeUpdate());
			System.out.println("5");
			
			
			
			
			
			
			conn.close();
			pstmt.close();
			//rs.close();
		} catch (SQLException e) {
			System.out.println("Exception thrown : SQLException ");
			e.printStackTrace();
		} finally {
			//DbConn.close(conn, pstmt, rs);
		}
	}

	public static void main(String[] args) {

		TestConn.select();
	}

}
