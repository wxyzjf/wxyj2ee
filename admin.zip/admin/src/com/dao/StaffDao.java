package com.dao;

import com.entity.Staff;

public interface StaffDao {
	public boolean insert(Staff staff);
	public boolean update(Staff staff);
	public Staff selectById(String id);
	
	
}
