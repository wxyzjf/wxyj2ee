package com.dao.impl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.dao.StaffDao;
import com.entity.Staff;

public class StaffDaoImpl implements StaffDao{
	private final static String DRIVER = "";
	private final static String URL = "";
	private final static String USERNAME = "";
	private final static String PASSWORD = "";
	
	

	@Override
	public boolean insert(Staff staff) {
		
		return false;
	}

	@Override
	public boolean update(Staff staff) {
		boolean flag = false;
		Connection conn;
		PreparedStatement psmt;
		try {
			Class.forName(DRIVER);
			conn = DriverManager.getConnection(URL, USERNAME, PASSWORD);
			psmt = conn.prepareStatement("");
			psmt.setString(1, "");
			if (psmt.executeUpdate()>0) {
				flag = true;
			}
			psmt.close();
			conn.close();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();		
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return flag;
	}

	@Override
	public Staff selectById(String id) {
		// TODO Auto-generated method stub
		return null;
	}
	
	
}
