package com.sql;

public class UserSql {
	public static String insertStaff = "";
	
	
	
}
