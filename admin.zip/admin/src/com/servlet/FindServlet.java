package com.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.entity.Staff;
import com.util.OdbcUtils;
import test.DbConn;

@WebServlet("/FindServlet")
public class FindServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		Connection conn = null;
		String sql = req.getParameter("sql");
		String reportType = "";
		try {
			conn = OdbcUtils.getConn();
			System.out.println(sql);
			switch (sql) {
			case "1":
				sql = "select staff_no,staff_ename,staff_cname,department,seat,shift_code,status,to_char(CHECKIN_DATE,'YYYY-MM-DD HH24:MI:SS') from eloise_dinner_check";
				pstmt = conn.prepareStatement(sql);
				reportType = "1";
				break;
			case "2":
				sql = "select staff_no,staff_ename,staff_cname,department,seat,shift_code,status,to_char(CHECKIN_DATE,'YYYY-MM-DD HH24:MI:SS') from eloise_dinner_check where status=?";
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, "Y");
				reportType = "2";
				break;
			case "3":
				sql = "select staff_no,staff_ename,staff_cname,department,seat,shift_code,status,to_char(CHECKIN_DATE,'YYYY-MM-DD HH24:MI:SS') from eloise_dinner_check where status=?";
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, "N");
				reportType = "3";
				break;
			default:
				break;
			}
			rs = pstmt.executeQuery();
			List<Staff> list = new ArrayList<Staff>();
			while (rs.next()) {
				Staff staff = new Staff();
				staff.setStaff_no(rs.getString("staff_no"));
				staff.setStaff_ename(rs.getString("staff_ename"));
				staff.setStaff_cname(rs.getString("staff_cname"));
				staff.setStaff_department(rs.getString("department"));
				staff.setSeat(rs.getString("seat"));
				staff.setShift_code(rs.getString("shift_code"));
				staff.setStatus(rs.getString("status"));
				
				staff.setCheckin_date(rs.getString(8));
				
				System.out.println(staff.getCheckin_date());

				list.add(staff);
			}
			req.setAttribute("list", list);
			req.setAttribute("reportType", reportType);
			//conn.close();
			pstmt.close();
			rs.close();
		} catch (SQLException e) {
			System.out.println("Exception thrown : SQLException ");
			e.printStackTrace();
		} finally {
			//DbConn.close(conn, pstmt, rs);
		}
		req.getRequestDispatcher("showReport.jsp").forward(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req, resp);
	}
}
