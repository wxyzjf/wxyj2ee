package com.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.util.OdbcUtils;

@WebServlet("/UnCheckinServlet")
public class UnCheckinServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		System.out.println("UpdateServlet");
		PreparedStatement pstmt = null;
		Connection conn = null;
		try {
			
			String staff_no = "G" + req.getParameter("staffId");
			System.out.println("staff_no = " + staff_no);
			String status = "N";
			String sql = "update eloise_dinner_check set status=?,CHECKIN_DATE=null where staff_no=?";
			conn = OdbcUtils.getConn();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, status);
			pstmt.setString(2, staff_no);

			int count = pstmt.executeUpdate();
			System.out.println(count);
			if (count>0) {
				System.out.println("update");
				String message = "Cancel Check-in successful.";
				req.getRequestDispatcher("alert_message.jsp?message=" + message).forward(req, resp);
			}
			

			//conn.close();
			pstmt.close();
		} catch (SQLException e) {
			System.out.println("Exception thrown : SQLException ");
			e.printStackTrace();
		} finally {
			/*
			 * if (conn != null) { try { conn.close(); } catch (Exception e) {
			 * System.out.println("Exception thrown : Connection cannot be closed ");
			 * e.printStackTrace(); } }
			 */
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (Exception e) {
					System.out.println("Exception thrown : Statement cannot be closed ");
					e.printStackTrace();
				}
			}
		}
	}
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req, resp);
	}
}
