package com.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.entity.Staff;
import com.util.OdbcUtils;

import test.DbConn;
/**
 * 更改数据时表单回显用的
 * @author EloiseWu
 *
 */
@WebServlet("/SelectServlet")
public class SelectServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		System.out.println("SelectServlet");

		PreparedStatement pstmt = null;
		ResultSet rs = null;
		Connection conn = null;
		
		String staffId = "G" + req.getParameter("staffId");
		String flag = req.getParameter("flag");
		System.out.println(flag);
		System.out.println("staffId = " + staffId);
		Staff staff = new Staff();
		try {
			String sql = "select staff_no,staff_ename,staff_cname,department,seat,shift_code,status,to_char(CHECKIN_DATE,'YYYY-MM-DD HH24:MI:SS') from eloise_dinner_check where staff_no=?";
			
			
			conn = OdbcUtils.getConn();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, staffId);
			
			rs = pstmt.executeQuery();
			

			while (rs.next()) {
				
				staff.setStaff_no(rs.getString("staff_no"));
				staff.setStaff_ename(rs.getString("staff_ename"));
				staff.setStaff_cname(rs.getString("staff_cname"));
				staff.setStaff_department(rs.getString("department"));
				staff.setSeat(rs.getString("seat"));
				staff.setShift_code(rs.getString("shift_code"));
				staff.setStatus(rs.getString("status"));
				staff.setCheckin_date(rs.getString(8));
				
			}
			System.out.println("staff" + staff);
			
			req.setAttribute("staff", staff);
			//conn.close();
			pstmt.close();
			rs.close();
		} catch (SQLException e) {
			System.out.println("Exception thrown : SQLException ");
			e.printStackTrace();
		} finally {
			//DbConn.close(conn, pstmt, rs);
		}
		System.out.println("staff.getStaff_no() = " + staff.getStaff_no());
		if (staff.getStaff_no()=="") {
			req.setAttribute("message", "No record found!");
			req.getRequestDispatcher("checkin_result.jsp").forward(req, resp);
		}else{
			if (staff.getStatus().equals("Y")) {				
				if (flag.equals("b")) {
					req.setAttribute("message", "Check-in successful.");
				}else if (flag.equals("c")){
					req.setAttribute("message", "Already check in before!");
				}else {
					req.setAttribute("message", "Check-in successful.");
				}
				req.getRequestDispatcher("checkin_result.jsp").forward(req, resp);
				return;
			}else if (staff.getStatus().equals("N")&&(staff.getShift_code().equals("@")||staff.getShift_code().equals("AL"))) {
				
				resp.sendRedirect("/admin/UpdateServlet?staffId=" + req.getParameter("staffId") + "&flag=b" );//flag=b
				return;
			}else if(staff.getStatus().equals("N")&&!staff.getShift_code().equals("@")&&!staff.getShift_code().equals("AL")){
				req.setAttribute("message", "Are you sure to check-in?");//flag=null
				req.getRequestDispatcher("checkin_result.jsp").forward(req, resp);
				return;
			}else {
				System.out.println("here");
			}
		}

	}
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req, resp);
	}
}
