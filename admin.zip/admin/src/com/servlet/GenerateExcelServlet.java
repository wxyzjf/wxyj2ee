package com.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import com.entity.Staff;
import com.util.OdbcUtils;

@WebServlet("/GenerateExcelServlet")
public class GenerateExcelServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		Connection conn = null;
		
		String sql = "";
		System.out.println("GenerateExcelServlet");
		String report_type = req.getParameter("report_type");
		String excelName = "";
		System.out.println(report_type);
		try {
			conn = OdbcUtils.getConn();
			
			switch (report_type) {
			case "1":
				sql = "select staff_no,staff_ename,staff_cname,department,seat,shift_code,status,to_char(CHECKIN_DATE,'YYYY-MM-DD HH24:MI:SS') from eloise_dinner_check";
				pstmt = conn.prepareStatement(sql);
				excelName = "All_Staff";
				break;
			case "2":
				sql = "select staff_no,staff_ename,staff_cname,department,seat,shift_code,status,to_char(CHECKIN_DATE,'YYYY-MM-DD HH24:MI:SS') from eloise_dinner_check where status=?";
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, "Y");
				excelName = "Uncheck_in_Staff";
				break;
			case "3":
				sql = "select staff_no,staff_ename,staff_cname,department,seat,shift_code,status,to_char(CHECKIN_DATE,'YYYY-MM-DD HH24:MI:SS') from eloise_dinner_check where status=?";
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, "N");
				excelName = "All_Staff";
				break;
			default:
				break;
			}
			rs = pstmt.executeQuery();
			List<Staff> list = new ArrayList<Staff>();
			while (rs.next()) {
				Staff staff = new Staff();
				staff.setStaff_no(rs.getString("staff_no"));
				staff.setStaff_ename(rs.getString("staff_ename"));
				staff.setStaff_cname(rs.getString("staff_cname"));
				staff.setStaff_department(rs.getString("department"));
				staff.setSeat(rs.getString("seat"));
				staff.setShift_code(rs.getString("shift_code"));
				staff.setStatus(rs.getString("status"));
				staff.setCheckin_date(rs.getString(8));
				list.add(staff);
			}
			//conn.close();
			pstmt.close();
			rs.close();
			generate(req,resp,list,excelName);
		} catch (SQLException e) {
			System.out.println("Exception thrown : SQLException ");
			e.printStackTrace();
		} finally {
			//DbConn.close(conn, pstmt, rs);
		}
		
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req, resp);
	}
	
	protected void generate(HttpServletRequest request, HttpServletResponse response,List<Staff> list,String excelName)
			throws ServletException, IOException {
       // response.setContentType("application/vnd.ms-excel");
        //response.setHeader("Content-Disposition", "inline; filename=" + excelName + ".xls");
		
		
		request.setCharacterEncoding("UTF-8");
		response.setContentType("application/vnd.ms-excel");//响应正文的MIME类型，表示Excel

        //String filePath="d:\\demo.xls";//设置文件路径
       ServletOutputStream out = response.getOutputStream();//响应输出流对象
       // FileOutputStream out = new FileOutputStream(filePath);//创建FileoutputStream对象
       // wb.write(out);  //将文件保存在对应的文件中
       
       
        HSSFWorkbook wb = new HSSFWorkbook();             //创建Excel表格
        HSSFSheet  sheet = wb.createSheet("staff");//创建工作簿
        sheet.setColumnWidth(100, 10000);                          //设置列宽
        HSSFRow titleRow = sheet.createRow(0);            //创建Excel中的标题行
        HSSFCell titleCell1 =titleRow .createCell(0);          //在行中创建第1个单元格
        titleCell1.setCellValue("STAFF_NO");               //设置第1个单元格的值
        HSSFCell titleCell2= titleRow.createCell(1);           //在行中创建第2个单元格
        titleCell2.setCellValue("STAFF_ENAME");                      //设置第2个单元格的值
        HSSFCell titleCell3 =titleRow .createCell(2);          //在行中创建第3个单元格
        titleCell3.setCellValue("STAFF_CNAME");                      //设置第3个单元格的值
        HSSFCell titleCell4= titleRow.createCell(3);           //在行中创建第4个单元格
        titleCell4.setCellValue("DEPARTMENT");                      //设置第4个单元格的值
        HSSFCell titleCell5 =titleRow .createCell(4);         
        titleCell5.setCellValue("SEAT");               
        HSSFCell titleCell6= titleRow.createCell(5);           
        titleCell6.setCellValue("SHIFT_CODE");                      
        HSSFCell titleCell7 =titleRow .createCell(6);          
        titleCell7.setCellValue("STATUS");                     
        HSSFCell titleCell8= titleRow.createCell(7);           
        titleCell8.setCellValue("CHECKIN_DATE");                      

        
        for (int i = 0; i < list.size(); i++) {
            HSSFRow valueRow = sheet.createRow(i+1);         //创建第2行
            HSSFCell staffno =valueRow .createCell(0);          //在行中创建第1个单元格
            staffno.setCellValue(list.get(i).getStaff_no());               //设置第1个单元格的值
            HSSFCell staffename= valueRow.createCell(1);           //在行中创建第2个单元格
            staffename.setCellValue(list.get(i).getStaff_ename());                      //设置第2个单元格的值
            HSSFCell staffcname =valueRow .createCell(2);          //在行中创建第3个单元格
            staffcname.setCellValue(list.get(i).getStaff_cname());                      //设置第3个单元格的值
            HSSFCell department= valueRow.createCell(3);           //在行中创建第4个单元格
            department.setCellValue(list.get(i).getStaff_department());                      //设置第4个单元格的值
            HSSFCell seat =valueRow .createCell(4);         
            seat.setCellValue(list.get(i).getSeat());               
            HSSFCell shiftcode= valueRow.createCell(5);           
            shiftcode.setCellValue(list.get(i).getShift_code());                      
            HSSFCell status =valueRow .createCell(6);          
            status.setCellValue(list.get(i).getStatus());                     
            HSSFCell checkindate= valueRow.createCell(7);           
            checkindate.setCellValue(list.get(i).getCheckin_date());
		}

        HSSFCellStyle cellStyle = wb.createCellStyle();

        wb.write(out);                              //将响应流输入到Excel表格中
        //response.addHeader("Content-Disposition", "attachment;filename=demo.xls");//文件临时保存在demo.xls中
        response.setHeader("Content-Disposition", "inline; filename=" + excelName + ".xls");
        out.flush();
        out.close();

  }
	
	
}
