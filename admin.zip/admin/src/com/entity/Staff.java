package com.entity;

public class Staff {
	private String staff_no;
	private String staff_ename;
	private String staff_cname;
	private String staff_department;
	private String seat;
	private String shift_code;
	public Staff() {
		
	}
	//无参
	public String getStaff_no() {return staff_no;}
	public void setStaff_no(String staff_no) {this.staff_no = staff_no;}
	public String getStaff_ename() {return staff_ename;}
	public void setStaff_ename(String staff_ename) {this.staff_ename = staff_ename;}
	public String getStaff_cname() {return staff_cname;}
	public void setStaff_cname(String staff_cname) {this.staff_cname = staff_cname;}
	public String getStaff_department() {return staff_department;}
	public void setStaff_department(String staff_department) {this.staff_department = staff_department;}
	public String getSeat() {return seat;}
	public void setSeat(String seat) {this.seat = seat;}
	public String getShift_code() {return shift_code;}
	public void setShift_code(String shift_code) {this.shift_code = shift_code;}
	@Override
	public String toString() {
		return "Staff [staff_no=" + staff_no + ", staff_ename=" + staff_ename + ", staff_cname=" + staff_cname
				+ ", staff_department=" + staff_department + ", seat=" + seat + ", shift_code=" + shift_code + "]";
	}
	

}
