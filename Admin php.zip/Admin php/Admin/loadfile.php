<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<script src="checkin.js" language="javascript"></script>
<link rel="stylesheet" href="checkin.css" type="text/css">
<title>Upload Staff List</title>
<?php
$db_host="localhost";
$db_user="root";
$db_pwd="123456";
$database="ad2012";

if (!mysql_connect($db_host, $db_user, $db_pwd)) {
    die("Can't connect to database");
}
     
if (!mysql_select_db($database)) {
    die("Can't select database");
}

mysql_query("set names 'utf8'");

$temp=file("2012.csv");

for ($i=0;$i<count($temp);$i++) {
    $string=explode(",",$temp[$i]);
    $string[2] = iconv("GBK","utf-8//ignore",$string[2]);
    //$string[2] = mb_convert_encoding($string[2],"utf-8","big5");
    $sql="insert into check_in_info (staff_id,staff_name_eng,staff_name_chi,department,seat_no,shift_code) values ('".$string[0]."','".$string[1]."','".$string[2]."','".trim($string[3])."','".$string[4]."','".trim($string[5])."')";
    $result = mysql_query($sql);

    if (!$result) {
	    die("Upload data failed");
    }
}
?>
</head>
<body>
    <span class="label">Upload Success!</span>
</body>			
</html>