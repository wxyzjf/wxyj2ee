﻿<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<script src="checkin.js" language="javascript"></script>
<link rel="stylesheet" href="checkin.css" type="text/css">
<title>Guangzhou Annual Dinner 2012 Admin</title>
<?php
$db_host="localhost";
$db_user="root";
$db_pwd="123456";
$database="ad2012";

$action = $_GET["action"];
?>
</head>
<body style="background-color:#000033">
<form id="reportForm" method="post" action="genReport.php" target="below">
<table width="100%" cellpadding="0" cellspacing="2">
  <col width="8%" />
  <col width="10%" />
  <col width="10%" />
  <col width="22%" />
  <col width="10%" />
  <col width="8%" />
  <col width="15%" />
  <col width="17%" />
  <tr>
	<td colspan=8 align="right"><input type="button" class="button" style="cursor:hand;" onclick="genReport()" value="Download Report"></td>
  </tr>
  <br/><br/>
  <tr>
    <td class="cell-label">Staff ID</td>
    <td class="cell-label">Eng Name</td>
    <td class="cell-label">Chi Name</td>
    <td class="cell-label">Department</td>
    <td class="cell-label">Shift Code</td>
    <td class="cell-label">Seat No.</td>
    <td class="cell-label">Check-in Status</td>
    <td class="cell-label">Check-in Date</td>
  </tr>
<?php
if ($action != "") {
    $sql = "";
    if ($action == "1") {
        $sql = "select staff_id,staff_name_eng,staff_name_chi,department,shift_code,seat_no,checkin_flag,checkin_date from check_in_info order by department, staff_id";
    } else if ($action == "2") {
        $sql = "select staff_id,staff_name_eng,staff_name_chi,department,shift_code,seat_no,checkin_flag,checkin_date from check_in_info where checkin_flag = 'Y' order by department, staff_id"; 
    } else if ($action == "3") {
        $sql = "select staff_id,staff_name_eng,staff_name_chi,department,shift_code,seat_no,checkin_flag,checkin_date from check_in_info where checkin_flag = 'N' order by department, staff_id";
    }
    
	if (!mysql_connect($db_host, $db_user, $db_pwd)) {
		die("Can't connect to database");
	}
     
	if (!mysql_select_db($database)) {
		die("Can't select database");
	}
    
    mysql_query("set names 'utf8'");

	$result =  mysql_query($sql);
	if (!$result) {
		die("Query to show fields from table failed");
	}
	
	$num_rows = mysql_num_rows($result);
    if ($num_rows == 0) {
?>
  <tr><td class="cell-data" colspan=8 align="center">No data found</td></tr>
<?php 
    } else {
    	while($row = mysql_fetch_row($result)) {
?>
    <tr>
      <td class="cell-data"><?php echo $row[0]?></td>
      <td class="cell-data"><?php echo $row[1]?></td>
      <td class="cell-data"><?php echo $row[2]?></td>
      <td class="cell-data"><?php echo $row[3]?></td>
      <td class="cell-data"><?php echo $row[4]?></td>
      <td class="cell-data"><?php echo $row[5]?></td>
      <td class="cell-data"><?php echo $row[6]?></td>
      <td class="cell-data"><?php echo $row[7]?></td>
    </tr>
<?php
	    }
?>
<input type="hidden" id="report_type" name="report_type" value="<?php echo $action?>"></input>
<?php
    }
    mysql_free_result($result);
}
?>
</table>
</form>
</body>
</html>