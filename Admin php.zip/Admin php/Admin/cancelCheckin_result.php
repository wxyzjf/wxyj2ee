<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<script src="checkin.js" language="javascript"></script>
<link rel="stylesheet" href="checkin.css" type="text/css">
<title>Guangzhou Annual Dinner 2012</title>		
<?php 
$db_host="localhost";
$db_user="root";
$db_pwd="123456";
$database="ad2012";

$action = $_POST["action"];
?>
</head>
<body>
<?php 
if ($action == 0) {
?>
<form id="form2" method="post" action="cancelcheckin_result.php">
<table width="100%" cellpadding="0" cellspacing="8">
  <col width="40%"/>
  <col width="60%"/>
<?php 
$staffId="G".$_POST["staffId"];
    
if (!mysql_connect($db_host, $db_user, $db_pwd)) {
	die("Can't connect to database");
}
     
if (!mysql_select_db($database)) {
	die("Can't select database");
}
      
mysql_query("set names 'utf8'");

$sql = "select staff_id,staff_name_eng,staff_name_chi,department,seat_no,checkin_flag,checkin_date,shift_code from check_in_info where staff_id = '" . $staffId ."'";

$result =  mysql_query($sql);
if (!$result) {
	die("Query to show fields from table failed");
}
	
$num_rows = mysql_num_rows($result);
if ($num_rows == 0) {
?>
    <span class="alert">No record found!</span>
<?php
} else if ($num_rows == 1) {
    $row = mysql_fetch_row($result);
    $staffId = $row[0];
    $staffNameEng = $row[1];
    $staffNameChi = $row[2];
    $department = $row[3];
    $seatNo = $row[4];
    $checkinFlag = $row[5];
    $checkinDate = $row[6];
    $shift_code = $row[7];
?>
  <tr>
    <td class="label">Staff ID:</td>
    <td class="content"><?php echo $staffId?></td>
  </tr>
  <tr>
    <td class="label">Staff Name:</td>
    <td class="content"><?php echo $staffNameEng?>&nbsp;<?php echo $staffNameChi?></td>
  </tr>
  <tr>
    <td class="label">Department:</td>
    <td class="content"><?php echo $department?></td>
  </tr>
  <tr>
    <td class="label">Seat No.:</td>
    <td class="content"><?php echo $seatNo?></td>
  </tr>
  <tr>
    <td class="label">Check-in Status:</td>
    <td class="content"><?php echo $checkinFlag?></td>
  </tr>
  <tr>
    <td class="label">Check-in Date:</td>
    <td class="content"><?php echo $checkinDate?></td>
  </tr>
   <tr>
    <td class="label">Shift Code:</td>
    <td class="content"><?php echo $shift_code?></td>
  </tr>
  <tr>
  	<td colspan="2">&nbsp;</td>
  </tr>
<?php
    if ($checkinFlag == "Y") {
?>
  <tr>
    <td><input type="button" class="button" value="Cancel Check-in" onclick="doCancelCheckin()"></td>
  </tr>
<?php
    }
?>
</table>
<input type="hidden" name="action" value="1"/>
<input type="hidden" name="staffId" value="<?php echo $staffId?>"/>
</form>
<?php
}
mysql_free_result($result);
} else if ($action == 1) { 
	$staffId=$_POST["staffId"];

	if (!mysql_connect($db_host, $db_user, $db_pwd)) {
		die("Can't connect to database");
	}

	if (!mysql_select_db($database)) {
		die("Can't select database");
	}

	$sql = "update check_in_info set checkin_flag='N', checkin_date=null where staff_id='".$staffId."' and checkin_flag='Y'";

	$result = mysql_query($sql);
	if (!$result) {
		die("Update table fields failed");
	}
?>
    <span class="alert">Cancel Check-in successful.</span>
<?php
}
?>
</body>
</html>
