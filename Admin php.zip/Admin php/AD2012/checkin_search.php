<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<script src="checkin.js" language="javascript"></script>
<link rel="stylesheet" href="checkin.css" type="text/css">
<title>Guangzhou Annual Dinner 2012</title>		
</head>
<body onload="doInit();">
<!--
<table width="100%" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td align="right" valign="top"><img src="logo.gif"></td>
  </tr>
</table>
-->
<span class="caption">GZ Annual Dinner 2012 Check-in</span><br>
<br>
<form id="form1" method="post" action="checkin_result.php" target="below" onkeydown="return doCheck()">
<table width="100%" cellpadding="0" cellspacing="10">
  <col width="30%"/>
  <col width="60%"/>
  <col width="10%"/>
  <tr>
    <td class="label">Staff ID:</td>
    <td><font class="label">G</font><input type="text" id="staffId" name="staffId" value="" class="textfield" size="10" maxlength="5" onkeydown="doSubmit()" onkeypress="return chkNumOnly()" pattern="[0-9]*"/>
  </tr>
  <tr>
    <td colspan="2">
      <input type="button" class="button" onclick="doValidate()" style="cursor:hand" value="Check-in"></input>
      &nbsp;&nbsp;&nbsp;&nbsp;
      <input type="button" class="button" onclick="doReset()" style="cursor:hand" value="Reset"></input>      
    </td>
  </tr>-
</table>
<input type="hidden" name="sure" value="N"/>
<input type="hidden" name="action" value="0"/>
</form>
<form id="form4" method="post" action="alert_message.php" target="below">
  <input type="hidden" name="message" id="message" value=""/>
</form>
<hr>
</body>			
</html>
