<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<link rel="stylesheet" href="checkin.css" type="text/css">
<title>Alert</title>		
</head>
<body>
<span class="alert"><?php echo $_POST["message"]?></span>
</body>