<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<script src="checkin.js" language="javascript"></script>
<link rel="stylesheet" href="checkin.css" type="text/css">
<title>Guangzhou Annual Dinner 2012</title>		
<?php 
$db_host="localhost";
$db_user="root";
$db_pwd="123456";
$database="ad2012";

$action = $_POST["action"];
?>
</head>
<body>
<?php 
if ($action == "0") {
	$staffId="G".$_POST["staffId"];
	$sure=$_POST["sure"];
    
	if (!mysql_connect($db_host, $db_user, $db_pwd)) {
		die("Can't connect to database");
	}
     
	if (!mysql_select_db($database)) {
		die("Can't select database");
	}
      
    mysql_query("set names 'utf8'");

	$sql = "select staff_id,staff_name_eng,staff_name_chi,department,seat_no,checkin_flag,checkin_date,shift_code from check_in_info where staff_id = '" . $staffId ."'";

	$result =  mysql_query($sql);
	if (!$result) {
		die("Query to show fields from table failed");
	}
	
	$num_rows = mysql_num_rows($result);
    if ($num_rows == 0) {
?>
    <span class="alert">No record found!</span>
<?php     
    } else if ($num_rows == 1) {
        $row = mysql_fetch_row($result);
	    $staffId = $row[0];
	    $staffNameEng = $row[1];
	    $staffNameChi = $row[2];
	    $department = $row[3];
	    $seatNo = $row[4];
	    $checkinFlag = $row[5];
	    $checkinDate = $row[6];
	    $shift_code = $row[7];
?>
<form id="form2" method="post" action="checkin_result.php">
<table width="100%" cellpadding="0" cellspacing="9">
  <col width="40%"/>
  <col width="60%"/>
<?php
    if (($checkinFlag == "N" && ($shift_code == "@" || $shift_code == "AL") && $sure == "N")||($checkinFlag == "N" && $sure == "Y")) {
        $sql = "update check_in_info set checkin_date=now(),checkin_flag='Y' where staff_id='".$staffId."' and checkin_flag='N'";

        $result = mysql_query($sql);
                
        if (!$result) {
            die("Update table fields failed");
        }
              
        $sql = "select staff_id,staff_name_eng,staff_name_chi,department,seat_no,checkin_flag,checkin_date,shift_code from check_in_info where staff_id = '" . $staffId ."'";

        $result =  mysql_query($sql);

        if (!$result) {
            die("Query to show fields from table failed");
	  }
	
        $row = mysql_fetch_row($result);
        $staffId = $row[0];
        $staffNameEng = $row[1];
        $staffNameChi = $row[2];
        $department = $row[3];
        $seatNo = $row[4];
        $checkinFlag = $row[5];
        $checkinDate = $row[6];
        $shift_code = $row[7];
?>
  <tr>
    <td class="alert" colspan="2">Check-in success</td>
  </tr>
<?php
    } else if ($shift_code != "@" && $shift_code != "AL" && $sure == "N" && $checkinFlag == "N") {
?>
  <tr>
    <td class="alert" colspan="2">Are you sure Check-in?</td>
  </tr>
<?php        
    } else {
?>
  <tr>
    <td class="alert" colspan="2">You have Check-in</td>
  </tr>
<?php
    }
?>
  <tr>
    <td class="label">Staff ID:</td>
    <td class="content"><?php echo $staffId?></td>
  </tr>
  <tr>
    <td class="label">Staff Name:</td>
    <td class="content"><?php echo $staffNameEng?>&nbsp;<?php echo $staffNameChi?></td>
  </tr>
  <tr>
    <td class="label">Department:</td>
    <td class="content"><?php echo $department?></td>
  </tr>
  <tr>
    <td class="label">Seat No.:</td>
    <td class="content"><?php echo $seatNo?></td>
  </tr>
  <tr>
    <td class="label">Check-in Status:</td>
    <td class="content"><?php echo $checkinFlag?></td>
  </tr>
  <tr>
    <td class="label">Check-in Date:</td>
    <td class="content"><?php echo $checkinDate?></td>
  </tr>
   <tr>
    <td class="label">Shift Code:</td>
    <td class="content"><?php echo $shift_code?></td>
  </tr>
  <tr>
  	<td colspan="2">&nbsp;</td>
  </tr>
  <tr>
  <?php
    if ($checkinFlag=="N") { 
  ?>
    <td align="left" colspan="2" >
      <input type="button" class="button" id="sureBtn" onclick="doCheckin();" style="cursor:hand" value="Check-in"></input>&nbsp;&nbsp;&nbsp;&nbsp;
      <input type="button" class="button" onclick="doClear()" style="cursor:hand" value="Cancel"></input>
    </td>
  <?php
    } else {
  ?>
    <td align="left" colspan="2"><input type="button" class="button" onclick="doClear()" style="cursor:hand" value="Clear"></input></td>
  <?php
    }
  ?>
  </tr>
</table>
<input type="hidden" name="action" value="0"/>
<input type="hidden" name="staffId" value="<?php echo $_POST["staffId"]?>"/>
<input type="hidden" name="sure" value="Y"/>
</form>
<?php
    }
    mysql_free_result($result);
}
?>
</body>			
</html>
